-- Eskiz Oyna — схема базы (PostgreSQL). Черновик для старта разработки.
-- Справочники (catalog_*, systems, passports, rules…) общие для всех цехов.
-- Всё, что принадлежит цеху, имеет company_id.

-- ===== Аккаунты (общие для семейства Eskiz) =====
CREATE TABLE companies (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  phone         text,
  logo_url      text,
  mode          text NOT NULL DEFAULT 'manufacturer' CHECK (mode IN ('manufacturer','dealer')), -- сам варю / заказываю у производителя
  dealer_coef   numeric(6,3),            -- для dealer: материалы × (1 + coef)
  markup_kind   text NOT NULL DEFAULT 'percent' CHECK (markup_kind IN ('percent','per_m2')),
  markup_value  numeric(12,2) NOT NULL DEFAULT 0,
  usd_rate      numeric(12,2),           -- свой курс; NULL = курс ЦБ
  install_gap_mm int NOT NULL DEFAULT 20,
  rounding_sum  int NOT NULL DEFAULT 1000,
  lang_default  text NOT NULL DEFAULT 'ru' CHECK (lang_default IN ('ru','uz')),
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone       text UNIQUE NOT NULL,
  name        text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE company_members (
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE,
  user_id     uuid REFERENCES users(id) ON DELETE CASCADE,
  role        text NOT NULL CHECK (role IN ('owner','manager','measurer','installer','production')),
  discount_limit_pct numeric(5,2) DEFAULT 0,
  PRIMARY KEY (company_id, user_id)
);

-- ===== Каталог =====
CREATE TABLE systems (
  code            text PRIMARY KEY,           -- akfa__6000_qvt
  brand           text NOT NULL,
  series          text NOT NULL,
  material_class  text NOT NULL,              -- pvc | alu_cold | alu_thermo | sill | ...
  passport_class  text,                       -- pvc_60 | pvc_70 | alu_cold | alu_thermo
  colors          text[] NOT NULL DEFAULT '{}',
  usable_for_calc boolean NOT NULL DEFAULT false
);

CREATE TABLE passports (
  class     text PRIMARY KEY,                 -- pvc_60 …; позже: код конкретной системы
  data      jsonb NOT NULL,                   -- см. passports.json
  verified  boolean NOT NULL DEFAULT false
);

CREATE TABLE price_versions (
  id          serial PRIMARY KEY,
  source      text NOT NULL,                  -- romchi_demo_2026-11 | supplier:<name>
  loaded_at   timestamptz NOT NULL DEFAULT now(),
  note        text
);

CREATE TABLE catalog_items (
  id            text PRIMARY KEY,             -- it00001
  system_code   text REFERENCES systems(code),
  brand         text NOT NULL,
  material_class text NOT NULL,
  article       text NOT NULL,                -- название как у поставщика
  role          text NOT NULL,                -- frame | sash | mullion | door_* | bead_* | reinforcement | seal | fit_* | sill | other …
  unit          text NOT NULL,                -- bar | m | kg | pcs | m2
  unit_confirmed boolean NOT NULL DEFAULT false,
  sill_depth_cm int,
  needs_review  boolean NOT NULL DEFAULT false
);

CREATE TABLE item_prices (
  price_version_id int REFERENCES price_versions(id),
  item_id     text REFERENCES catalog_items(id),
  color       text NOT NULL,                  -- 'Белый', 'Ламинация', … или '—'
  price_sum   numeric(14,2),                  -- NULL = «нет цены»
  updated     date,
  PRIMARY KEY (price_version_id, item_id, color)
);

-- Цены цеха поверх базовых (меняет только свои позиции)
CREATE TABLE company_prices (
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE,
  item_id     text REFERENCES catalog_items(id),
  color       text NOT NULL,
  price_sum   numeric(14,2) NOT NULL,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (company_id, item_id, color)
);

CREATE TABLE company_systems (               -- с какими системами работает цех
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE,
  system_code text REFERENCES systems(code),
  PRIMARY KEY (company_id, system_code)
);

CREATE TABLE glass_types (
  code          text PRIMARY KEY,             -- g4_16_4
  formula       text NOT NULL,
  thickness_mm  int NOT NULL,
  glass_mm_total int NOT NULL,
  weight_kg_m2  numeric(6,2) NOT NULL
);

CREATE TABLE glass_prices (                   -- прайс стекольщика; company_id NULL = базовый
  company_id   uuid REFERENCES companies(id) ON DELETE CASCADE,
  glass_code   text REFERENCES glass_types(code),
  price_sum_m2 numeric(14,2) NOT NULL,
  min_area_m2  numeric(6,3) NOT NULL DEFAULT 0.3,
  shaped_extra_pct numeric(5,2) DEFAULT 0,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE fitting_rules (
  id            serial PRIMARY KEY,
  fitting_system text NOT NULL,               -- generic | fapim_galicube | …
  opening       text NOT NULL,                -- tilt_turn | turn | tilt | door | sliding
  part_code     text NOT NULL,
  part_name     text NOT NULL,
  item_id       text REFERENCES catalog_items(id), -- привязка к позиции каталога (может быть NULL до разметки)
  w_from int, w_to int, h_from int, h_to int,
  qty_expr      text NOT NULL DEFAULT '1',    -- число или выражение от w, h
  when_expr     text,                          -- handle | hinge=left | …
  status        text
);

CREATE TABLE extra_products (                 -- сопутствующие: сетки, жалюзи, рольставни
  id            serial PRIMARY KEY,
  company_id    uuid REFERENCES companies(id) ON DELETE CASCADE, -- NULL = справочный
  category      text NOT NULL,
  name          text NOT NULL,
  unit          text NOT NULL,                -- pcs | m2 | m
  price_sum     numeric(14,2),
  includes_install boolean,
  source_url    text
);

CREATE TABLE work_rates (
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE,
  work_code   text NOT NULL,                  -- install | dismantle | slopes | …
  unit        text NOT NULL,
  price_sum   numeric(14,2) NOT NULL,
  PRIMARY KEY (company_id, work_code)
);

CREATE TABLE kits (                           -- комплектации цеха: «Эконом», «Стандарт», «Тёплый»
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE,
  name        text NOT NULL,
  setup       jsonb NOT NULL                  -- {"system":…, "color_out":…, "color_in":…, "glass":…, "fittings":…}
);

CREATE TABLE templates (
  id          text PRIMARY KEY,               -- T01 … или uuid для шаблонов цеха
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE, -- NULL = системный
  name        text NOT NULL,
  kind        text NOT NULL,
  default_w   int, default_h int,
  root        jsonb NOT NULL
);

-- ===== Заказы =====
CREATE TABLE clients (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE,
  name        text,
  phone       text,
  telegram    text,
  lang        text DEFAULT 'ru'
);

CREATE TABLE orders (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid REFERENCES companies(id) ON DELETE CASCADE,
  client_id   uuid REFERENCES clients(id),
  address     text,
  floor       int,
  status      text NOT NULL DEFAULT 'measure' CHECK (status IN ('measure','quoted','agreed','production','ready','installed','closed','cancelled')),
  discount_pct numeric(5,2) DEFAULT 0,
  works       jsonb NOT NULL DEFAULT '{}',    -- доставка, этаж, работа снаружи
  created_by  uuid REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  client_rev  bigint NOT NULL DEFAULT 0       -- для синхронизации офлайн-замера
);

CREATE TABLE order_positions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id    uuid REFERENCES orders(id) ON DELETE CASCADE,
  sort        int NOT NULL DEFAULT 0,
  doc         jsonb NOT NULL,                 -- изделие целиком (модель в PRD, раздел 6)
  photos      text[] DEFAULT '{}',
  accepted_warnings jsonb NOT NULL DEFAULT '[]', -- [{"rule":"2.3","by":uuid,"at":ts}]
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE extra_lines (                    -- строки сопутствующих товаров в заказе
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id    uuid REFERENCES orders(id) ON DELETE CASCADE,
  name        text NOT NULL,
  unit        text NOT NULL,
  qty         numeric(10,3) NOT NULL,
  price_sum   numeric(14,2) NOT NULL
);

CREATE TABLE quotes (                         -- версии КП с замороженными ценами
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id    uuid REFERENCES orders(id) ON DELETE CASCADE,
  version     int NOT NULL,
  price_version_id int REFERENCES price_versions(id),
  usd_rate    numeric(12,2),
  lang        text NOT NULL,
  variants    jsonb NOT NULL,                 -- до 3 комплектаций: позиции, итоги, цены
  public_token text UNIQUE NOT NULL,          -- ссылка для клиента
  sent_at     timestamptz,
  accepted_at timestamptz,
  UNIQUE (order_id, version)
);

CREATE INDEX ON catalog_items (system_code, role);
CREATE INDEX ON orders (company_id, status, updated_at DESC);
CREATE INDEX ON order_positions (order_id);
