import csv, json, re, collections
import sys; src=sys.argv[1] if len(sys.argv)>1 else 'romchi_raw.csv'
rows=list(csv.DictReader(open(src)))

def slug(s):
    s=s.lower().replace("'", "").replace("`","")
    s=re.sub(r'\(неполный[^)]*\)|\(возможно неполный\)','',s)
    s=re.sub(r'[^a-z0-9]+','_',s).strip('_')
    return s

TYPE_ROLE={'Угловой':'frame','Крыло':'sash','Средний':'mullion',
           'Балкон Угловой':'door_frame','Балкон Крыло':'door_sash','Балкон Средний':'door_mullion'}
MAT={'PVC':'pvc','Aluminium':'alu_cold','Thermo':'alu_thermo','Thermo aluminium':'alu_thermo',
     'Sill':'sill','PVC accessory':'pvc_accessory','Aluminium accessory':'alu_accessory',
     'Seal':'seal','Hardware':'hardware','Machine':'machine'}

def role_from_name(n, mat):
    s=n.lower()
    bal = 'balkon' in s or 'балкон' in s
    if re.search(r'stanok',s): return 'machine'
    if mat in ('pvc','alu_cold','alu_thermo'):
        m=re.search(r'\(\s*([lzt])\s*\)|\b([lzt])\s+oval|\bbalkon\s+([lzt])\b',s)
        if m and not re.search(r'archa|moskit|maskit',s):
            k=(m.group(1) or m.group(2) or m.group(3))
            base={'l':'frame','z':'sash','t':'mullion'}[k]
            return ('door_'+base) if bal else base
    if re.search(r'podokonnik|tokcha|подоконник',s): return 'sill'
    if re.search(r'shtapik|штапик',s):
        if re.search(r'uchtalik|uch',s): return 'bead_triple'
        if re.search(r'odinar|24mm',s): return 'bead_single'
        return 'bead_igu'
    if re.search(r'shtulp|штульп',s) and not re.search(r'ruchag|shpingalet|planka',s): return 'shtulp'
    if re.search(r'lambri|lmabri',s): return 'lambri'
    if re.search(r'metall|armatur|армир',s): return 'reinforcement'
    if re.search(r'rezina|epdm|tpv|uplotn|уплотн',s): return 'seal'
    if re.search(r'nojnitsa|ножниц',s): return 'fit_scissors'
    if re.search(r'petlya|dv\.? ?otk|dv\. ?otk|петл',s): return 'fit_hinge'
    if re.search(r'ruchka|ruchag|ручк',s): return 'fit_handle'
    if re.search(r'zamok|zapor|tsalfa|otvetn|serdtsevina|shpingalet|замок',s): return 'fit_lock'
    if re.search(r'soed|chovush|соедин|chift quloq|klipsa',s): return 'connector'
    if re.search(r'gradus|razvarot',s): return 'joint_profile'
    if re.search(r'truba|turba|usilitel|ulanish|usilenniy profil|kvadrat profil',s): return 'coupling_profile'
    if re.search(r'porog|parog',s): return 'threshold'
    if re.search(r'moskit|maskit|sinaks',s): return 'mosquito_profile'
    if re.search(r'archa',s): return 'corner_cleat'
    if re.search(r'otvetka',s): return 'fit_lock'
    if re.search(r'lapsha',s): return 'thermo_insert'
    if re.search(r'rucha\b|ruchka',s): return 'fit_handle'
    if re.search(r'poliamid',s): return 'thermo_insert'
    if mat in ('pvc','alu_cold','alu_thermo'):
        if re.search(r'\bkosa\b',s): return 'door_frame' if bal else 'frame'
        if re.search(r'qanot',s): return 'door_sash' if bal else 'sash'
        if re.search(r"o.?rta|urta|\borta\b",s): return 'door_mullion' if bal else 'mullion'
    return 'other'

UNIT={'frame':'bar','sash':'bar','mullion':'bar','door_frame':'bar','door_sash':'bar','door_mullion':'bar',
      'bead_single':'bar','bead_igu':'bar','bead_triple':'bar','shtulp':'bar','lambri':'bar',
      'reinforcement':'bar','thermo_insert':'bar','sill':'m','seal':'kg',
      'joint_profile':'bar','coupling_profile':'bar','threshold':'bar','mosquito_profile':'bar'}

items=[]; sys_stats=collections.OrderedDict()
for i,r in enumerate(rows,1):
    mat=MAT[r['material']]
    series_clean=re.sub(r'\s*\((неполный[^)]*|возможно неполный)\)','',r['series']).strip()
    incomplete='1' if 'неполн' in r['series'] else '0'
    role=TYPE_ROLE.get(r['type']) or role_from_name(r['article'],mat)
    unit=UNIT.get(role,'pcs')
    syscode=slug(r['brand'])+'__'+slug(series_clean)
    m=re.search(r'(\d{2})\b',r['article']) if role=='sill' else None
    items.append(dict(item_id=f'it{i:05d}',brand=r['brand'],material_class=mat,system_code=syscode,
        series=series_clean,price_updated=r['updated'],color=r['color'],pos=r['pos'],type_ru=r['type'],
        article=r['article'],role=role,unit=unit,unit_confirmed='0' if unit in('bar','m','kg') else '1',
        sill_depth_cm=m.group(1) if m else '',price_sum=r['price_sum'],
        has_price='1' if r['price_sum'] else '0',series_incomplete=incomplete,
        needs_review='1' if role=='other' else '0',source='romchi_demo_2026-11'))
    st=sys_stats.setdefault(syscode,dict(system_code=syscode,brand=r['brand'],series=series_clean,material_class=mat,
        colors=set(),roles=set(),items=0,no_price=0,updated=r['updated'],incomplete=incomplete))
    st['colors'].add(r['color']); st['roles'].add(role); st['items']+=1; st['no_price']+= (r['price_sum']=='')

with open('catalog_items.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(items[0].keys())); w.writeheader(); w.writerows(items)

def pclass(st):
    m=st['material_class']; s=st['series'].lower()
    if m=='pvc':
        num=re.search(r'(\d{4})',s)
        n=int(num.group(1)) if num else 6000
        return 'pvc_70' if n>=6500 else 'pvc_60'
    if m=='alu_cold': return 'alu_cold'
    if m=='alu_thermo': return 'alu_thermo'
    return ''
with open('systems.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['system_code','brand','series','material_class','passport_class','colors','has_frame','has_sash','has_mullion','has_door_profiles','items','items_without_price','price_updated','series_incomplete','usable_for_calc'])
    for st in sys_stats.values():
        r_=st['roles']; pc=pclass(st)
        usable = pc!='' and {'frame','sash','mullion'}<=r_
        w.writerow([st['system_code'],st['brand'],st['series'],st['material_class'],pc,'|'.join(sorted(c for c in st['colors'] if c!='—')),
            int('frame' in r_),int('sash' in r_),int('mullion' in r_),int(bool(r_&{'door_frame','door_sash','door_mullion'})),
            st['items'],st['no_price'],st['updated'],st['incomplete'],int(usable)])

c=collections.Counter(x['role'] for x in items)
print(len(items), c.most_common())
print('systems',len(sys_stats),'usable',sum(1 for s in sys_stats.values() if pclass(s) and {'frame','sash','mullion'}<=s['roles']))
