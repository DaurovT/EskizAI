"""Загрузка демо-данных Eskiz Oyna в PostgreSQL.

Использование:
    pip install psycopg[binary]
    psql "$DATABASE_URL" -f schema.sql
    python seed_import.py "$DATABASE_URL"

Скрипт идемпотентный только для справочников (ON CONFLICT DO NOTHING).
Цены грузятся в новую версию прайса при каждом запуске.
"""
import csv
import json
import sys
from pathlib import Path

import psycopg

HERE = Path(__file__).parent


def main(dsn: str) -> None:
    with psycopg.connect(dsn) as con, con.cursor() as cur:
        # системы
        for r in csv.DictReader(open(HERE / "systems.csv", encoding="utf-8")):
            cur.execute(
                """INSERT INTO systems (code, brand, series, material_class, passport_class, colors, usable_for_calc)
                   VALUES (%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (code) DO NOTHING""",
                (r["system_code"], r["brand"], r["series"], r["material_class"],
                 r["passport_class"] or None, [c for c in r["colors"].split("|") if c],
                 r["usable_for_calc"] == "1"),
            )

        # паспорта
        passports = json.load(open(HERE / "passports.json", encoding="utf-8"))
        for cls, data in passports.items():
            if cls.startswith("_"):
                continue
            cur.execute(
                "INSERT INTO passports (class, data, verified) VALUES (%s,%s,%s) ON CONFLICT (class) DO NOTHING",
                (cls, json.dumps(data, ensure_ascii=False), bool(data.get("verified"))),
            )

        # каталог + цены
        cur.execute(
            "INSERT INTO price_versions (source, note) VALUES (%s,%s) RETURNING id",
            ("romchi_demo_2026-11", "Демо-цены, собраны вручную из приложения Romchi"),
        )
        pv = cur.fetchone()[0]
        for r in csv.DictReader(open(HERE / "catalog_items.csv", encoding="utf-8")):
            cur.execute(
                """INSERT INTO catalog_items (id, system_code, brand, material_class, article, role, unit,
                                              unit_confirmed, sill_depth_cm, needs_review)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (id) DO NOTHING""",
                (r["item_id"], r["system_code"], r["brand"], r["material_class"], r["article"], r["role"],
                 r["unit"], r["unit_confirmed"] == "1", int(r["sill_depth_cm"]) if r["sill_depth_cm"] else None,
                 r["needs_review"] == "1"),
            )
            cur.execute(
                """INSERT INTO item_prices (price_version_id, item_id, color, price_sum, updated)
                   VALUES (%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
                (pv, r["item_id"], r["color"], r["price_sum"] or None, r["price_updated"] or None),
            )

        # стеклопакеты (без цен — цены задаёт цех)
        for r in csv.DictReader(open(HERE / "glass.csv", encoding="utf-8")):
            cur.execute(
                """INSERT INTO glass_types (code, formula, thickness_mm, glass_mm_total, weight_kg_m2)
                   VALUES (%s,%s,%s,%s,%s) ON CONFLICT (code) DO NOTHING""",
                (r["glass_code"], r["formula"], int(r["thickness_mm"]), int(r["glass_mm_total"]),
                 float(r["weight_kg_m2"])),
            )

        # правила фурнитуры
        for r in csv.DictReader(open(HERE / "fitting_rules.csv", encoding="utf-8")):
            def num(v):
                return int(v) if v else None
            cur.execute(
                """INSERT INTO fitting_rules (fitting_system, opening, part_code, part_name,
                                              w_from, w_to, h_from, h_to, qty_expr, when_expr, status)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (r["fitting_system"], r["opening"], r["part_code"], r["part_name"], num(r["w_from"]),
                 num(r["w_to"]), num(r["h_from"]), num(r["h_to"]), r["qty"], r["when"] or None, r["status"]),
            )

        # сопутствующие товары (справочные)
        for r in csv.DictReader(open(HERE / "extra_products.csv", encoding="utf-8")):
            price = r["price_min_sum"] or None
            cur.execute(
                """INSERT INTO extra_products (company_id, category, name, unit, price_sum, includes_install, source_url)
                   VALUES (NULL,%s,%s,%s,%s,%s,%s)""",
                (r["category"], r["item"], r["unit"], price, r["includes_install"] == "да", r["source_url"] or None),
            )

        # шаблоны
        for t in json.load(open(HERE / "templates.json", encoding="utf-8"))["templates"]:
            cur.execute(
                """INSERT INTO templates (id, company_id, name, kind, default_w, default_h, root)
                   VALUES (%s,NULL,%s,%s,%s,%s,%s) ON CONFLICT (id) DO NOTHING""",
                (t["id"], t["name"], t["kind"], t["default_w"], t["default_h"],
                 json.dumps(t["root"], ensure_ascii=False)),
            )
        con.commit()
    print("Готово")


if __name__ == "__main__":
    main(sys.argv[1])
